import os
import nest_asyncio
import asyncio

from llama_index.core.memory import ChatSummaryMemoryBuffer
from llama_index.core.llms import ChatMessage
from llama_index.llms.ollama import Ollama
from llama_index.core.agent.workflow import FunctionAgent
from llama_index.core.workflow import Context

# Patch nested event loop support for Jupyter/Windows
nest_asyncio.apply()

# Use Ollama-compatible chat model
llm = Ollama(model="tinyllama")  # or try "openchat"

# Summary memory setup
memory = ChatSummaryMemoryBuffer.from_defaults(token_limit=40000)

# Add previous chat history to memory
chat_history = [
    ChatMessage(role="user", content="Hello, how are you?"),
    ChatMessage(role="assistant", content="I'm doing well, thank you!"),
]
memory.put_messages(chat_history)

# Define FunctionAgent (no tools used here)
agent = FunctionAgent(tools=[], llm=llm)

# Create context to hold chat history/state
ctx = Context(agent)

# Async wrapper to run agent in an event loop
async def run_agent():
    response = await agent.run("Hello again, can you help me?", ctx=ctx, memory=memory)
    print("\nAgent response:", response)
    print("\nAll memory:")
    print(memory.get_all())

# Manually create and run event loop (Windows-safe)
loop = asyncio.get_event_loop()
loop.run_until_complete(run_agent())
