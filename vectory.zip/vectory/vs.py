from llama_index.core.memory import VectorMemory
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.core.llms import ChatMessage

# Use OllamaEmbedding instead of OpenAIEmbedding
embedding_model = OllamaEmbedding(model_name="all-minilm")
  # You can also try "llama3"

vector_memory = VectorMemory.from_defaults(
    vector_store=None,
    embed_model=embedding_model,
    retriever_kwargs={"similarity_top_k": 1},
)

# Initial messages
msgs = [
    ChatMessage.from_str("Jerry likes juice.", "user"),
    ChatMessage.from_str("Bob likes burgers.", "user"),
    ChatMessage.from_str("Alice likes apples.", "user"),
]

# Load into memory
for m in msgs:
    vector_memory.put(m)

# Retrieve based on query
msgs = vector_memory.get("What does Jerry like?")
print("Query 1 Result:")
for msg in msgs:
    print(msg)

# Reset memory
vector_memory.reset()

# New messages
msgs = [
    ChatMessage.from_str("Jerry likes burgers.", "user"),
    ChatMessage.from_str("Bob likes apples.", "user"),
    ChatMessage.from_str("Indeed, Bob likes apples.", "assistant"),
    ChatMessage.from_str("Alice likes juice.", "user"),
]
vector_memory.set(msgs)

# Retrieve again
msgs = vector_memory.get("What does Bob like?")
print("\nQuery 2 Result:")
for msg in msgs:
    print(msg)
