from llama_index.core.memory import ChatMemoryBuffer
from llama_index.core.llms import ChatMessage
from llama_index.core.agent.workflow import FunctionAgent
from llama_index.core.workflow import Context
from llama_index.llms.ollama import Ollama
import asyncio  # Needed for async

# Step 1: Setup ChatMemoryBuffer
memory = ChatMemoryBuffer.from_defaults(token_limit=40000)

# Step 2: Add initial chat history
chat_history = [
    ChatMessage(role="user", content="Hello, how are you?"),
    ChatMessage(role="assistant", content="I'm doing well, thank you!"),
]
memory.put_messages(chat_history)

# Step 3: Use Ollama LLM
ollama_llm = Ollama(model="gemma3:1b")  # You can also try "mistral", "codellama", etc.

# Step 4: Create the FunctionAgent
agent = FunctionAgent(tools=[], llm=ollama_llm)

# Step 5: Create context
ctx = Context(agent)

# Step 6: Run agent (async)
async def main():
    resp = await agent.run("Hello, how are you?", ctx=ctx, memory=memory)
    print("Response:", resp)
    print("Full chat memory:")
    print(memory.get_all())

# Step 7: Execute
asyncio.run(main())
