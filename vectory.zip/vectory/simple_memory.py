import nest_asyncio
nest_asyncio.apply()

from llama_index.core.memory import (
    VectorMemory,
    SimpleComposableMemory,
    ChatMemoryBuffer,
)
from llama_index.core.llms import ChatMessage
from llama_index.llms.ollama import Ollama
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.core.tools import FunctionTool
from llama_index.core.agent import FunctionCallingAgent

# ✅ Step 1: Define tools
def multiply(a: int, b: int) -> int:
    """Multiply two integers and return the result."""
    return a * b

def mystery(a: int, b: int) -> int:
    """Mystery function: a^2 - b^2"""
    return a**2 - b**2

# ✅ Step 2: Create FunctionTools
multiply_tool = FunctionTool.from_defaults(fn=multiply)
mystery_tool = FunctionTool.from_defaults(fn=mystery)

# ✅ Step 3: Setup embedding model (lighter one)
embedding_model = OllamaEmbedding(model_name="nomic-embed-text")

# ✅ Step 4: Setup LLM (must support tools)
llm = Ollama(model="mistral")


# ✅ Step 5: Setup vector memory
vector_memory = VectorMemory.from_defaults(
    vector_store=None,
    embed_model=embedding_model,
    retriever_kwargs={"similarity_top_k": 2},
)

# ✅ Step 6: Seed vector memory with relevant messages
seed_messages = [
    ChatMessage(role="user", content="What is the mystery function on 5 and 6?"),
    ChatMessage(role="assistant", content=str(mystery(5, 6))),
    ChatMessage(role="user", content="What happens if you multiply 2 and 3?"),
    ChatMessage(role="assistant", content=str(multiply(2, 3))),
]
for msg in seed_messages:
    vector_memory.put(msg)

# ✅ Step 7: Setup primary memory
chat_memory_buffer = ChatMemoryBuffer.from_defaults()

# ✅ Step 8: Combine into composable memory
composable_memory = SimpleComposableMemory.from_defaults(
    primary_memory=chat_memory_buffer,
    secondary_memory_sources=[vector_memory],
)

# ✅ Step 9: Create agent with memory and tools
agent = FunctionCallingAgent.from_tools(
    tools=[multiply_tool, mystery_tool],
    llm=llm,
    memory=composable_memory,
    verbose=True,
)

# ✅ Step 10: Run agent conversations
print("\n🧠 1. Mystery function:")
response1 = agent.chat("What is the mystery function on 5 and 6?")
print(response1)

print("\n🔢 2. Multiply:")
response2 = agent.chat("What happens if you multiply 2 and 3?")
print(response2)

print("\n📦 3. Recall mystery result (without recomputing):")
response3 = agent.chat("What was the output of the mystery function on 5 and 6 again? Don't recompute.")
print(response3)

print("\n📦 4. Recall multiply result (without recomputing):")
response4 = agent.chat("What was the output of the multiply function on 2 and 3 again? Don't recompute.")
print(response4)

# ✅ Step 11: Inspect retrieved memory directly
print("\n🧠 Retrieved memory content:")
mem_output = agent.memory.get("What was the output of the mystery function on 5 and 6 again?")
print(mem_output[0])
